# torna 'starter' um pacote Python
